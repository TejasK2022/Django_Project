from django.contrib import admin
from .models import blooddonatordb
from .models import bloodacceptordb
# Register your models here.
admin.site.register(blooddonatordb)
admin.site.register(bloodacceptordb)