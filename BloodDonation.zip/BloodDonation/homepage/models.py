from django.db import models

# Create your models here.
class bloodacceptordb(models.Model):
    Id=models.IntegerField(primary_key=True)
    Name=models.CharField(max_length=100)
    Address=models.CharField(max_length=150)
    Age=models.IntegerField()
    Mobile=models.IntegerField()
    Email=models.EmailField(max_length=30)
    BloodGroup=models.CharField(max_length=30,default='A')
    DoctorName=models.CharField(max_length=30,default='Add One')
    Gender=models.CharField(max_length=30,default='M')
    Password=models.CharField(max_length=15,default=True)
class blooddonatordb(models.Model):
    Id=models.IntegerField(primary_key=True)
    Name=models.CharField(max_length=100)
    Address=models.CharField(max_length=150)
    Age=models.IntegerField()
    Mobile=models.IntegerField()
    Email=models.EmailField(max_length=40)
    BloodGroup=models.CharField(max_length=10,default='O')
    Weight=models.IntegerField(max_length=3)
    NearLocation=models.CharField(max_length=25)
    Dieses=models.CharField(max_length=200)
    Gender=models.CharField(max_length=20,default='M')