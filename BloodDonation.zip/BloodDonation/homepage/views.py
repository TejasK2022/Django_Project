from django.shortcuts import render, redirect
from django.utils.datastructures import MultiValueDictKeyError
from .models import bloodacceptordb
from .models import blooddonatordb
from django.db.models import Max


# Create your views here.
def index(request):
    return render(request,'index.html')
def bloodacceptor(request):
    return render(request,'bloodacceptor.html')
def blooddonator(request):
    return render(request,'blooddonator.html')
def blooddonatorsuccess(request):
    id =2001 if blooddonatordb.objects.count() == 0 else blooddonatordb.objects.aggregate(max=Max('Id'))["max"] + 1
    if request.method == 'POST':
        name=request.POST['name']
        address=request.POST['location']
        age=request.POST['age']
        mobile=request.POST['phone']
        mail=request.POST['mail']
        bloodgroup=request.POST['blood']
        weight=request.POST['weight']
        nearlocation=request.POST['nearlocation']
        dieses=request.POST['dieses']
        gender=request.POST['gender']
        bd=blooddonatordb(request.POST)
        bd.Id=id
        bd.Name=name
        bd.Address=address
        bd.Age=age
        bd.Mobile=mobile
        bd.Email=mail
        bd.BloodGroup=bloodgroup
        bd.Weight=weight
        bd.NearLocation=nearlocation
        bd.Dieses=dieses
        bd.Gender=gender
        bd.save()

    return render(request,'Blooddonatorsuccess.html')
def AcceptorRegister(request):
    id = 1001 if bloodacceptordb.objects.count() == 0 else bloodacceptordb.objects.aggregate(max=Max('Id'))["max"] + 1
    if request.method=='POST':

        name=request.POST['name']
        location=request.POST['location']
        age=request.POST['age']
        mobile=request.POST['phone']
        mail=request.POST['mail']
        bloodgroup=request.POST['blood']
        doctor=request.POST['doctor']
        gender=request.POST['gender']
        password=request.POST['acceptorpass']
        ba=bloodacceptordb(request.POST)
        ba.Id=id
        ba.Name=name
        ba.Address=location
        ba.Age=age
        ba.Mobile=mobile
        ba.Email=mail
        ba.BloodGroup=bloodgroup
        ba.DoctorName=doctor
        ba.Gender=gender
        ba.Password=password
        ba.save()

    return render(request,'AcceptorRegister.html')
def adminlogin(request):
    return render(request,'adminlogin.html')
def adminloginsuccess(request):
    adminname=request.POST['adminname']
    adminpassword=request.POST['adminpassword']
    if adminname=='admin' and adminpassword=='admin':
        return render(request,'adminloginsuccess.html',{'visitor':adminname})
    else:
        return render(request,'adminloginfail.html')

def viewacceptorrequest(request):
    x=bloodacceptordb.objects.all()

    return render(request,'viewacceptorrequest.html',{'records':x})
def viewdonatorrequest(request):
    y=blooddonatordb.objects.all()
    return render(request,'viewdonatorrequest.html',{'donatorrecord':y})
def userloginsuccess(request):
    return render(request,'userloginsuccess.html')
def userlogin(request):
    return render(request,'userlogin.html')
def userloginsuccess(request):
    a=request.POST['userusername']
    b=request.POST['userpassword']
    if a=='user' and b=='user':
        return render(request,'userloginsuccess.html',{'visitor':a})
def bloodtest(request):
    return render(request,'bloodtest.html')
def freecamps(request):
    return render(request,'Freecamps.html')
def adminloginfail(request):
    return render(request,'adminloginfail.html')
def Training(request):
    return render(request,'Training.html')
def mybloodrequest(request):
    return render(request,'mybloodrequest.html')
def acceptorhistory(request):
    x = bloodacceptordb.objects.all()
    return render(request,'acceptorhistory.html',{'records':x})
def donatorhistory(request):
    y = blooddonatordb.objects.all()
    return render(request,'donatorhistory.html',{'donatorrecord':y})

